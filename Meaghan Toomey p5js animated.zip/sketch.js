var x1= 160;
var x2 = 260;
var y1= 270;
var y2 = 270;
var x3 = 140;
var y3 = 195;

var eyeMovement1;
var eyeMovement2;
var shoulderMovement1;
var shoulderMovement2;
var blushMovement;
var titleSize = 50;
var titleBigger = 1;

function setup() {
  createCanvas(400, 400);
  eyeMovement1 = Math.floor(Math.random() * 10) / 2;
  eyeMovement2 = Math.floor(Math.random() * 10) / 2;
  shoulderMovement1 = Math.floor(Math.random() * 10) / 2;
  shoulderMovement2 = Math.floor(Math.random() * 10) / 2;
  blushMovement = Math.floor(Math.random() * 10) / 2;
}

function draw() {
background('#d5e19d');
  strokeWeight(1);
  stroke('#402213');
  //hair
  fill('#402213');
  triangle(60, 320, 125, 50, 200, 300);
  triangle(200, 300, 275, 50, 340, 320);
  //skin
  fill('#ffeee0');
  rect(165, 230, 70, 40); //hair
  circle(200, 150, 200); //face
  triangle(190, 200, 200, 150, 210, 200); //nose
  line(170, 210, 180, 220); // smile
  line(180, 220, 220, 220);
  line(220, 220, 230, 210);
  //eyes
  fill('#fff7eb')
  ellipse(150, 150, 60, 40);
  ellipse(250, 150, 60, 40);
  fill('#5a4a40')
  circle(x1, 150, 30);
  circle(x2, 150, 30);
  if(x1 >= 160){
    eyeMovement1*=-1;
  }
  if(x1 <= 140){
    eyeMovement1*=-1;
  }
  x1 += eyeMovement1;
  
  if(x2 >= 260){
    eyeMovement2*=-1;
  }
  if(x2 <= 240){
    eyeMovement2*=-1;
  }
  x2 += eyeMovement2;
  
  //hoodie
  fill('#b6bd71')
  rect(100, 270, 200, 200);
  //hoodie strings
  stroke('fff7eb');
  line(165, 270, 165, 340);
  line(235, 270, 235, 340);
  stroke('#402213');
  triangle(100, 270, 165, 270, 200, 300); //hood of hoodie
  triangle(300, 270, 235, 270, 200, 300);
  rect(80, y1, 50, 200);
  rect(270, y2, 50, 200);
  if(y1 >= 260){
    shoulderMovement1*=-1;
  }
  if(y1 <= 270){
    shoulderMovement1*=-1;
  }
  y1 += shoulderMovement1;
  
  if(y2 >= 260){
    shoulderMovement2*=-1;
  }
  if(y2 <= 270){
    shoulderMovement2*=-1;
  }
  y2 += shoulderMovement2;
  //undershirt
  fill('#fff7eb');
  triangle(165, 270, 235, 270, 200, 300);
  //hair
  fill('#402213');
  rect(100, 40, 200, 80);
  rect(75, 50, 40, 250);
  rect(285, 50, 40, 250);
  //title
  
  textSize(titleSize);
  text('Self Portrait', 10, 360);
  if(titleSize >= 50){
    titleBigger*=-1;
  }
  if(titleSize <= 10){
    titleBigger*=-1;
  }
  titleSize += titleBigger;
  textSize(10)
  text('By Meaghan Toomey', 10, 375);
  //blush
  strokeWeight(40);
  stroke('#fdd5c8');
  point(x3, y3);
  point(260, 195);
  
  if(x3 >= 140){
    blushMovement*=-1;
  }
  if(x3 <= 40){
    blushMovement*=-1;
  }
  x3 += blushMovement;
  y3 += blushMovement;
  
  
}